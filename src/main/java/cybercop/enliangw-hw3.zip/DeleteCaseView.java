//Enliang Wu
//enliangw
package hw3;

import javafx.scene.Scene;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DeleteCaseView extends CaseView {

    public DeleteCaseView(String header) {
        super(header);
    }

    @Override
    Stage buildView() {
        //Set up the stage
        stage.setScene(new Scene(updateCaseGridPane, CASE_WIDTH, CASE_HEIGHT));
        closeButton.setOnAction(event -> stage.close());
        clearButton.setOnAction(event -> {
            titleTextField.clear();
            caseDatePicker.setValue(LocalDate.now());
            caseTypeTextField.clear();
            caseNumberTextField.clear();
            categoryTextField.clear();
            caseLinkTextField.clear();
            caseNotesTextArea.clear();
        });
        updateButton.setText("Delete case");
        updateCaseData(CyberCop.currentCase);

        return stage;
    }

    public void updateCaseData(Case c) {
        //Set the text
        titleTextField.setText(c.getCaseTitle());
        caseDatePicker.setValue(LocalDate.parse(c.getCaseDate(), DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        caseTypeTextField.setText(c.getCaseType());
        caseNumberTextField.setText(c.getCaseNumber());
        categoryTextField.setText(c.getCaseCategory());
        caseLinkTextField.setText(c.getCaseLink());
        caseNotesTextArea.setText(c.getCaseNotes());

    }
}
